require "/scripts/util.lua"
require "/quests/scripts/questutil.lua"
require "/scripts/vec2.lua"
require "/scripts/lofty_irisil_util.lua"

local originalInit = init
local originalUpdate = update
local originalUninit = uninit

function init()
	originalInit()
end

local li_heldItemName = ""

function update(dt)

	originalUpdate(dt)
	
	--get the player's currently held cursor / swap item
	local held = player.swapSlotItem()
	if held then
		--yeek("R1", "true")
		--for k,v in pairs(held) do yeek(k.." : "..tostring(v)) end
		--yeek("R1", "parameter count: " .. #held.parameters)
		--for k,v in pairs(held.parameters) do yeek(k.." : "..tostring(v)) end
		
		local conf = root.itemConfig(held.name)
		--for k,v in pairs(conf) do yeek(k.." : "..tostring(v)) end
		
		if conf.config.lofty_redrarity then
			if conf.config.lofty_bordered then
				if conf.config.lofty_altItem then
					player.setSwapSlotItem(conf.config.lofty_altItem)
				end
			end
		end
	else
		--scan their inventory for borderless items and replace with bordered ones
		local items = player.itemsWithTag("lofty_red_rarity_replace_me_furniture")
		if items then
			--fill the player's inventory with crap
			--local x = 0
			--for x = 0, 240 do
				--player.giveItem("lofty_irisil_furniture_blocker")
			--end
			
			--get the alt item
			if items[1] then
				for k,v in pairs(items[1]) do yeek(k.." : "..tostring(v)) end
				yeek("arg")
				for k,v in pairs(items[1].parameters) do yeek(k.." : "..tostring(v)) end
			
				local conf = root.itemConfig(items[1].name)
				local altItem = conf.config.lofty_altItem
				
				--consume the item
				player.consumeItem(items[1].name)
				
				--give the alt item
				player.giveItem(altItem)
				
				--remove the crap items
				player.consumeTaggedItem("lofty_irisil_rarity_remove_me", 240)
			end
		end
	end
end

function uninit()
	originalUninit()
end